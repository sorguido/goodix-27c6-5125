# D233 independent live-backend safety review

Second pass performed treating the new source as dangerous. Review scope was
the D232 refactor, D233 source/tests, static entrypoint reachability, protected
files and bundle policy. No hardware or system mutation was used.

## Findings

- The shipped entrypoint calls only `dict` and `request_live_mode`. Normal use
  returns capability zero; every supplied flag/environment/config/backend name
  raises. It cannot construct `LibusbSystemApi`, a transport, OS facade or
  protected-file loader.
- AST inspection confirms all nine real libusb ABI methods call the
  unconditional source seal. Direct `LibusbSystemApi.init()` was tested and
  stopped before `libusb_init`. D234 needs an explicit source edit.
- VID/PID, interface and endpoints are exact. No wildcard, fallback, detach,
  auto-detach, clear-halt or reset symbol exists. Identity includes descriptor,
  bus, address and port path and is revalidated around phases.
- Resource state is monotonic; cleanup continues through errors and release,
  close and context exit are each bounded to once. Tests cover open/claim
  failures, wrong identity, partial I/O, timeout, malformed framing and
  re-enumeration.
- D232's exact order/serializer/response checks are reused, not copied. Its
  public synthetic type gate remains. All D232 tests pass after refactoring.
- D4/E0/A4/F0/F4 remain forbidden and have no builder path. There is no
  firmware, provisioning, recovery, retry, thread or application-data API.
- TLS bounds are exact and the real loopback negotiated TLS 1.2
  `PSK-AES128-GCM-SHA256`. Wrong identity/suite/version, alert, Bad Record MAC
  and second handshake fail terminally. No session ticket or key logging path
  exists.
- The same `SecretBuffer` is bound and consumed by TLS. Constant-time compare
  and zeroization are implemented. However, the OEM KDF implementation is not
  in the corpus, so target binding is correctly not claimed.
- `0x90` remains external, hash-pinned and cross-correlated. The identified
  local capture is provenance-valid; raw material is excluded from D233.
- OS stop/restore and signal handling are injected and exactly restored in
  offline tests. The single-use marker is atomic and intentionally durable.
- Reports remain atomic mode-0600, redacted and published in failure paths.

## Blocking result

No hard-disable, USB/TLS/B0, cleanup, report, retry, allowlist or provenance
defect was found. One mandatory readiness gate is genuinely unresolved:
the target `KDF_OEM(out A)` implementation needed for same-run PSK↔E4 binding.

`INDEPENDENT_REVIEW=pass` means the implementation accurately enforces and
reports this blocker; it does not mean D234 is ready or authorized.

`D233_BLOCKED_BY_RUNTIME_PSK_E4_BINDING`
