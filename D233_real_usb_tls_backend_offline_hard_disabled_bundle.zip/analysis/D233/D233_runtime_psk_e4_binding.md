# D233 runtime PSK ↔ E4 binding

## Implemented gate

`RuntimePskE4Binder` receives the same mutable `SecretBuffer` later handed to
the TLS server. During the E4 phase it:

1. requires the exact typed E4 prefix and a 32-byte validator;
2. invokes one injected validator derivation on the loaded PSK view;
3. compares expected and device bytes with `hmac.compare_digest`;
4. zeroizes the temporary expected buffer in `finally`;
5. raises a terminal secret-boundary abort on mismatch.

`ProductionReplayBackend.exchange` performs this gate before returning E4 to
the shared state machine. Consequently A2 is unreachable on mismatch. There is
no cached-MATCH, replacement PSK, default, random or fallback branch.

## Provenance blocker

The local canonical corpus establishes:

```text
PSK_TLS = out A
validator = KDF_OEM(out A)
```

It does not contain the concrete KDF algorithm or the former private D189–D206
derivation artifacts. A hash of the target validator and a historical E4 MATCH
cannot reconstruct or replace that algorithm. Tests therefore use a clearly
domain-separated synthetic SHA-256 derivation solely to prove control flow,
constant-time comparison and failure placement.

```text
RUNTIME_PSK_E4_BINDING_IMPLEMENTED=yes
RUNTIME_PSK_E4_BINDING_OFFLINE_TESTED=yes
RUNTIME_PSK_E4_BINDING_PROVEN=no
D233_BLOCKED_BY_RUNTIME_PSK_E4_BINDING
```

No production KDF is guessed. D234 remains impossible until a provenance-valid
implementation and target vector are recovered and independently reviewed.
