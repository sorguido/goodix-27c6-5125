# D259 classifier/error recovery matrix

| condition | gf_update_all_base_result | final_0x32 | retry_or_rebuild | a2_reentry | 0x70_reentry | other_recovery_command | evidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| classifier_return_0_1_2_3_negative_or_other | 1_SUCCESS | REACHABLE | NONE | 0 | 0 | NONE | all switch arms converge at 0x1800694fa/0x1800696b4; return remains [rsp+0x44]=1 |
| earlier_acquisition_or_protocol_failure | 0_FAILURE | NOT_REACHED_BY_CALLER | ONLY_EARLIER_DELTA_FALLBACK_OR_LOOP; NOT_CLASSIFIER_CAUSED | 0 | 0 | NONE_IN_CALLER_BRANCH | failure writes [rsp+0x44]=0; caller 0x18006898f branches away from 0x180068abe |
